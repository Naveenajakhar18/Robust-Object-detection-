# MongoDB Schema

## Database: `object_detection`

---

## Collection: `detections`

Stores each image detection run.

```json
{
  "_id": "ObjectId",
  "timestamp": "ISODate",
  "filename": "string",
  "image_url": "string (URL to annotated image)",
  "objects_detected": [
    {
      "label": "string (e.g. person, car)",
      "confidence": "float (0.0–1.0)",
      "bbox": {
        "x": "int",
        "y": "int",
        "width": "int",
        "height": "int"
      },
      "class_id": "int (COCO class ID)"
    }
  ],
  "inference_time_ms": "float",
  "confidence_threshold": "float",
  "user_id": "string | null"
}
```

**Indexes:**
- `timestamp` (descending) — for sorted queries
- `user_id` — for user-scoped queries

---

## Collection: `images`

Optional: stores raw image metadata.

```json
{
  "_id": "ObjectId",
  "filename": "string",
  "upload_time": "ISODate",
  "size_bytes": "int",
  "content_type": "string",
  "metadata": {}
}
```

---

## Collection: `users`

Stores registered users.

```json
{
  "_id": "ObjectId",
  "email": "string (unique)",
  "password": "string (bcrypt hashed)",
  "name": "string",
  "role": "string (user | admin)",
  "created_at": "ISODate"
}
```

**Indexes:**
- `email` (unique)
