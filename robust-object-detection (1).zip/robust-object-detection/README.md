# 🔍 Robust Object Detection System

A production-ready SaaS-style AI application for real-time object detection using **YOLOv8 + FastAPI + React + MongoDB**.

---

## 🚀 Quick Start (Local)

### Prerequisites
- **Python 3.10+**
- **Node.js 18+**
- **MongoDB** running locally OR a free [MongoDB Atlas](https://cloud.mongodb.com) cluster

---

### 1. Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy env file
cp .env.example .env
# Edit .env if needed (MongoDB URI, JWT secret, etc.)

# Start the server
uvicorn main:app --reload --port 8000
```

Backend runs at: **http://localhost:8000**
API Docs (Swagger): **http://localhost:8000/docs**

---

### 2. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Copy env file
cp .env.example .env
# Set VITE_API_URL=http://localhost:8000

# Start the dev server
npm run dev
```

Frontend runs at: **http://localhost:5173**

---

### 3. MongoDB

**Option A — Local:**
```bash
# Install MongoDB Community Edition and start:
mongod --dbpath /data/db
# MONGODB_URI=mongodb://localhost:27017
```

**Option B — Atlas (free cloud):**
1. Go to https://cloud.mongodb.com
2. Create a free M0 cluster
3. Get your connection string
4. Set `MONGODB_URI=mongodb+srv://...` in `backend/.env`

---

### 4. Docker Compose (all-in-one)

```bash
# From project root:
docker-compose up --build
```

- Frontend: http://localhost:5173
- Backend: http://localhost:8000
- MongoDB: localhost:27017

---

## 📁 Project Structure

```
robust-object-detection/
├── backend/
│   ├── main.py               # FastAPI app entry point
│   ├── routes/
│   │   ├── detection.py      # /detect-image, /detect-video
│   │   ├── auth.py           # /auth/login, /auth/register
│   │   └── history.py        # /history, /analytics
│   ├── services/
│   │   ├── yolo_service.py   # YOLOv8 inference
│   │   ├── db_service.py     # MongoDB CRUD
│   │   └── storage_service.py# Annotated image saving
│   ├── models/
│   │   └── detection_model.py# Pydantic schemas
│   ├── utils/
│   │   └── auth_utils.py     # JWT + bcrypt
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx      # Analytics charts
│   │   │   ├── ImageDetection.jsx # Upload + detect
│   │   │   ├── LiveDetection.jsx  # Webcam stream
│   │   │   ├── History.jsx        # Detection history
│   │   │   ├── Login.jsx
│   │   │   └── Register.jsx
│   │   ├── components/
│   │   │   ├── Layout.jsx              # Sidebar nav
│   │   │   ├── BoundingBoxCanvas.jsx   # Canvas bbox renderer
│   │   │   └── DetectionResultCard.jsx # Result item
│   │   ├── services/
│   │   │   └── api.js            # Axios API calls
│   │   ├── context/
│   │   │   └── AuthContext.jsx   # JWT auth state
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── .env.example
│
├── database/
│   └── schema.md             # MongoDB collection schemas
├── docker-compose.yml
└── README.md
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| POST | `/api/detect-image` | Upload image for detection |
| GET | `/api/detect-video` | MJPEG webcam stream |
| GET | `/api/history` | Paginated detection history |
| GET | `/api/analytics` | Dashboard analytics |
| DELETE | `/api/history/{id}` | Delete a detection |
| POST | `/api/auth/register` | Register user |
| POST | `/api/auth/login` | Login user |
| GET | `/api/auth/me` | Get current user |

Full interactive docs: **http://localhost:8000/docs**

---

## 🌍 Production Deployment

### Backend → Render
1. Push `backend/` to GitHub
2. Create a new **Web Service** on [Render](https://render.com)
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Add environment variables: `MONGODB_URI`, `JWT_SECRET`, `BASE_URL`

### Frontend → Vercel
1. Push `frontend/` to GitHub
2. Import on [Vercel](https://vercel.com)
3. Set environment variable: `VITE_API_URL=https://your-backend.onrender.com`
4. Deploy

### Database → MongoDB Atlas
1. Create free cluster at https://cloud.mongodb.com
2. Whitelist `0.0.0.0/0` or Render's IP
3. Copy connection string to backend env

---

## 🧩 Features

- ✅ YOLOv8n object detection (80 COCO classes)
- ✅ Image upload with annotated output
- ✅ Confidence threshold slider
- ✅ Live webcam stream (frontend + backend modes)
- ✅ Detection history with MongoDB
- ✅ Analytics dashboard with Recharts
- ✅ JWT authentication (register/login)
- ✅ Export results as JSON
- ✅ Download annotated images
- ✅ Docker Compose for one-command startup
- ✅ Swagger UI auto-docs
- ✅ Dark mode premium UI

---

## 🐛 Troubleshooting

**`ERR_CONNECTION_REFUSED` on localhost:5173**
→ Frontend dev server is not running. Run `npm run dev` inside the `frontend/` folder.

**Backend 500 error on first detection**
→ YOLOv8 downloads `yolov8n.pt` (~6MB) on first run. Wait a moment and retry.

**MongoDB connection error**
→ Make sure MongoDB is running locally (`mongod`) or your Atlas URI is correct in `.env`.

**CORS errors in browser**
→ Ensure `VITE_API_URL` in frontend `.env` matches the exact backend address.
