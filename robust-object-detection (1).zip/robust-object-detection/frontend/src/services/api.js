import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
  timeout: 60000,
})

// Response interceptor for error handling
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export const detectImage = async (file, confidenceThreshold = 0.25) => {
  const formData = new FormData()
  formData.append('file', file)
  const { data } = await api.post(
    `/api/detect-image?confidence_threshold=${confidenceThreshold}`,
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } }
  )
  return data
}

export const getHistory = async (page = 1, limit = 20) => {
  const { data } = await api.get(`/api/history?page=${page}&limit=${limit}`)
  return data
}

export const getAnalytics = async () => {
  const { data } = await api.get('/api/analytics')
  return data
}

export const deleteDetection = async (id) => {
  const { data } = await api.delete(`/api/history/${id}`)
  return data
}

export const login = async (email, password) => {
  const { data } = await api.post('/api/auth/login', { email, password })
  return data
}

export const register = async (name, email, password) => {
  const { data } = await api.post('/api/auth/register', { name, email, password })
  return data
}

export const getVideoStreamUrl = () =>
  `${import.meta.env.VITE_API_URL || 'http://localhost:8000'}/api/detect-video`

export default api
