import { useEffect, useState } from 'react'
import { getHistory, deleteDetection } from '../services/api'
import toast from 'react-hot-toast'
import { Trash2, ExternalLink, ChevronLeft, ChevronRight, History as HistoryIcon, Loader2 } from 'lucide-react'

const LABEL_COLORS = ['bg-accent/20 text-accent-soft','bg-neon-cyan/20 text-neon-cyan',
  'bg-neon-green/20 text-neon-green','bg-neon-amber/20 text-neon-amber','bg-pink-500/20 text-pink-400']

export default function History() {
  const [data, setData] = useState(null)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const [deleting, setDeleting] = useState(null)

  const fetch = async (p = page) => {
    setLoading(true)
    try {
      const res = await getHistory(p)
      setData(res)
    } catch {
      toast.error('Failed to load history')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetch(page) }, [page])

  const handleDelete = async (id) => {
    setDeleting(id)
    try {
      await deleteDetection(id)
      toast.success('Deleted')
      fetch(page)
    } catch {
      toast.error('Delete failed')
    } finally {
      setDeleting(null)
    }
  }

  return (
    <div className="max-w-5xl space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold">Detection History</h1>
        <p className="text-white/40 text-sm mt-1">All past detections stored in MongoDB</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-accent" />
        </div>
      ) : !data || data.items.length === 0 ? (
        <div className="card p-16 text-center">
          <HistoryIcon size={40} className="text-white/10 mx-auto mb-4" />
          <p className="font-display font-semibold text-white/40">No detections yet</p>
          <p className="text-sm text-white/20 mt-1">Upload an image to get started</p>
        </div>
      ) : (
        <>
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-surface-600 text-white/40 font-mono text-xs uppercase">
                  <th className="px-4 py-3 text-left">Timestamp</th>
                  <th className="px-4 py-3 text-left">Filename</th>
                  <th className="px-4 py-3 text-left">Objects</th>
                  <th className="px-4 py-3 text-left">Labels</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((item, i) => (
                  <tr key={item.id} className="border-b border-surface-700/50 hover:bg-surface-700/30 transition-colors">
                    <td className="px-4 py-3 text-white/50 font-mono text-xs whitespace-nowrap">
                      {new Date(item.timestamp).toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-white/80 max-w-[140px] truncate">
                      {item.filename || '—'}
                    </td>
                    <td className="px-4 py-3">
                      <span className="badge bg-accent/20 text-accent-soft">
                        {item.objects_detected?.length ?? 0}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {[...new Set((item.objects_detected || []).map(o => o.label))]
                          .slice(0, 4)
                          .map((label, j) => (
                            <span key={label} className={`badge ${LABEL_COLORS[j % LABEL_COLORS.length]}`}>
                              {label}
                            </span>
                          ))
                        }
                        {(item.objects_detected?.length ?? 0) > 4 && (
                          <span className="badge bg-surface-600 text-white/40">
                            +{item.objects_detected.length - 4}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        {item.image_url && (
                          <a href={item.image_url} target="_blank" rel="noreferrer"
                            className="text-white/30 hover:text-neon-cyan transition-colors p-1">
                            <ExternalLink size={14} />
                          </a>
                        )}
                        <button
                          onClick={() => handleDelete(item.id)}
                          disabled={deleting === item.id}
                          className="text-white/30 hover:text-red-400 transition-colors p-1 disabled:opacity-40"
                        >
                          {deleting === item.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {data.pages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-white/40 text-sm">
                Page {data.page} of {data.pages} · {data.total} total
              </p>
              <div className="flex gap-2">
                <button onClick={() => setPage(p => p - 1)} disabled={page === 1} className="btn-ghost py-2 px-3 disabled:opacity-40">
                  <ChevronLeft size={16} />
                </button>
                <button onClick={() => setPage(p => p + 1)} disabled={page === data.pages} className="btn-ghost py-2 px-3 disabled:opacity-40">
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
