import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { register as registerApi } from '../services/api'
import toast from 'react-hot-toast'
import { Scan, Loader2 } from 'lucide-react'

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (form.password.length < 8) return toast.error('Password must be at least 8 characters')
    setLoading(true)
    try {
      const data = await registerApi(form.name, form.email, form.password)
      login(data.access_token, data.user)
      toast.success('Account created!')
      navigate('/')
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm animate-slide-up">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center mx-auto mb-4 shadow-xl shadow-accent-glow">
            <Scan size={24} className="text-white" />
          </div>
          <h1 className="text-2xl font-display font-bold">Create account</h1>
          <p className="text-white/40 text-sm mt-1">Get started for free</p>
        </div>

        <form onSubmit={handleSubmit} className="card p-6 space-y-4">
          {[
            { key: 'name', label: 'Full Name', type: 'text', placeholder: 'Jane Doe' },
            { key: 'email', label: 'Email', type: 'email', placeholder: 'you@example.com' },
            { key: 'password', label: 'Password', type: 'password', placeholder: '8+ characters' },
          ].map(({ key, label, type, placeholder }) => (
            <div key={key}>
              <label className="text-xs text-white/50 font-mono mb-1.5 block">{label}</label>
              <input type={type} required value={form[key]} onChange={set(key)}
                placeholder={placeholder} className="input" />
            </div>
          ))}
          <button type="submit" disabled={loading} className="w-full btn-primary flex items-center justify-center gap-2">
            {loading ? <><Loader2 size={15} className="animate-spin" /> Creating…</> : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-white/40 text-sm mt-4">
          Have an account?{' '}
          <Link to="/login" className="text-accent hover:text-accent-soft transition-colors">Sign in</Link>
        </p>
      </div>
    </div>
  )
}
