import { useEffect, useState } from 'react'
import { getAnalytics } from '../services/api'
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { Scan, TrendingUp, Layers, Target, ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'

const ACCENT_COLORS = ['#6c47ff','#00d4ff','#00ff94','#ffb347','#ff6b6b','#c084fc','#34d399','#fbbf24']

const StatCard = ({ icon: Icon, label, value, sub, color = 'accent' }) => (
  <div className="card p-5 animate-slide-up">
    <div className="flex items-start justify-between mb-4">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
        color === 'cyan' ? 'bg-neon-cyan/10' : color === 'green' ? 'bg-neon-green/10' : 'bg-accent/10'
      }`}>
        <Icon size={18} className={
          color === 'cyan' ? 'text-neon-cyan' : color === 'green' ? 'text-neon-green' : 'text-accent'
        } />
      </div>
    </div>
    <p className="text-3xl font-display font-bold">{value ?? '—'}</p>
    <p className="text-sm text-white/60 mt-1 font-body">{label}</p>
    {sub && <p className="text-xs text-white/30 mt-0.5">{sub}</p>}
  </div>
)

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-surface-700 border border-surface-500 rounded-xl px-4 py-3 text-sm shadow-xl">
      <p className="text-white/60 mb-1 font-mono text-xs">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }} className="font-semibold">
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  )
}

export default function Dashboard() {
  const [analytics, setAnalytics] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getAnalytics()
      .then(setAnalytics)
      .catch(() => setAnalytics({ total_detections: 0, total_objects: 0, daily_data: [], top_labels: [], unique_classes: 0 }))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="space-y-6">
      <div className="h-8 w-48 shimmer rounded-xl" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <div key={i} className="h-36 shimmer rounded-2xl" />)}
      </div>
    </div>
  )

  return (
    <div className="space-y-8 max-w-6xl">
      {/* Header */}
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold glow-text">Dashboard</h1>
          <p className="text-white/40 text-sm mt-1">Real-time detection analytics & insights</p>
        </div>
        <Link to="/detect" className="btn-primary flex items-center gap-2 text-sm">
          <Scan size={15} />
          New Detection
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Scan} label="Total Detections" value={analytics.total_detections} />
        <StatCard icon={Layers} label="Objects Found" value={analytics.total_objects} color="cyan" />
        <StatCard icon={Target} label="Unique Classes" value={analytics.unique_classes} color="green" />
        <StatCard icon={TrendingUp} label="Avg per Scan"
          value={analytics.total_detections
            ? Math.round(analytics.total_objects / analytics.total_detections)
            : 0}
        />
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Area chart */}
        <div className="card p-6 lg:col-span-2">
          <h2 className="font-display font-semibold mb-1">Detections Over Time</h2>
          <p className="text-white/40 text-xs mb-6">Last 30 days activity</p>
          {analytics.daily_data.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-white/30 text-sm">
              No data yet — run your first detection!
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={analytics.daily_data}>
                <defs>
                  <linearGradient id="colorDet" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6c47ff" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6c47ff" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorObj" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#00d4ff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} tickLine={false} axisLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="detections" name="Detections" stroke="#6c47ff" fill="url(#colorDet)" strokeWidth={2} dot={false} />
                <Area type="monotone" dataKey="objects" name="Objects" stroke="#00d4ff" fill="url(#colorObj)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Top labels */}
        <div className="card p-6">
          <h2 className="font-display font-semibold mb-1">Top Classes</h2>
          <p className="text-white/40 text-xs mb-5">Most detected objects</p>
          {analytics.top_labels.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-white/30 text-sm text-center">
              No detections yet
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={analytics.top_labels} layout="vertical">
                <XAxis type="number" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis dataKey="label" type="category" tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} tickLine={false} axisLine={false} width={60} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="count" name="Count" radius={[0, 4, 4, 0]}>
                  {analytics.top_labels.map((_, i) => (
                    <Cell key={i} fill={ACCENT_COLORS[i % ACCENT_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid sm:grid-cols-3 gap-4">
        {[
          { to: '/detect', label: 'Upload & Detect', desc: 'Analyze images with YOLOv8', icon: '🖼️' },
          { to: '/live', label: 'Live Webcam', desc: 'Real-time detection stream', icon: '📹' },
          { to: '/history', label: 'View History', desc: 'Browse past detections', icon: '📋' },
        ].map(({ to, label, desc, icon }) => (
          <Link key={to} to={to} className="card p-5 hover:border-accent/40 transition-all duration-200 hover:-translate-y-0.5 group">
            <div className="text-2xl mb-3">{icon}</div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-display font-semibold text-sm">{label}</p>
                <p className="text-white/40 text-xs mt-0.5">{desc}</p>
              </div>
              <ArrowRight size={16} className="text-white/20 group-hover:text-accent transition-colors" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
