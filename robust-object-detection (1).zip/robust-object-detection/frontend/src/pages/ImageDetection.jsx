import { useState, useRef, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { detectImage } from '../services/api'
import toast from 'react-hot-toast'
import { Upload, ImageIcon, Download, Sliders, X, Loader2, CheckCircle2, AlertCircle } from 'lucide-react'
import BoundingBoxCanvas from '../components/BoundingBoxCanvas'
import DetectionResultCard from '../components/DetectionResultCard'
import clsx from 'clsx'

export default function ImageDetection() {
  const [selectedFile, setSelectedFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [confidence, setConfidence] = useState(0.25)
  const imgRef = useRef(null)

  const onDrop = useCallback((acceptedFiles) => {
    const file = acceptedFiles[0]
    if (!file) return
    setSelectedFile(file)
    setPreview(URL.createObjectURL(file))
    setResult(null)
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: { 'image/*': [] }, multiple: false, maxSize: 10485760
  })

  const handleDetect = async () => {
    if (!selectedFile) return toast.error('Please select an image first')
    setLoading(true)
    try {
      const data = await detectImage(selectedFile, confidence)
      setResult(data)
      toast.success(`Detected ${data.total_objects} object${data.total_objects !== 1 ? 's' : ''}!`)
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Detection failed. Is the backend running?')
    } finally {
      setLoading(false)
    }
  }

  const handleClear = () => {
    setSelectedFile(null)
    setPreview(null)
    setResult(null)
  }

  const handleDownload = () => {
    if (!result?.image_url) return
    const a = document.createElement('a')
    a.href = result.image_url
    a.download = `detected_${selectedFile?.name || 'result.jpg'}`
    a.click()
  }

  const exportJSON = () => {
    if (!result) return
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'detection_result.json'
    a.click()
  }

  return (
    <div className="max-w-5xl space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-display font-bold">Image Detection</h1>
        <p className="text-white/40 text-sm mt-1">Upload an image to detect objects using YOLOv8</p>
      </div>

      {/* Confidence Slider */}
      <div className="card p-4 flex items-center gap-4">
        <Sliders size={16} className="text-accent shrink-0" />
        <div className="flex-1">
          <div className="flex justify-between text-xs text-white/50 mb-1.5">
            <span>Confidence Threshold</span>
            <span className="font-mono text-accent">{Math.round(confidence * 100)}%</span>
          </div>
          <input
            type="range" min="0.05" max="0.95" step="0.05"
            value={confidence}
            onChange={e => setConfidence(parseFloat(e.target.value))}
            className="w-full accent-[#6c47ff] cursor-pointer"
          />
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upload zone */}
        <div className="space-y-4">
          <div
            {...getRootProps()}
            className={clsx(
              'border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200',
              isDragActive ? 'border-accent bg-accent/5' : 'border-surface-500 hover:border-accent/50 hover:bg-surface-700/50'
            )}
          >
            <input {...getInputProps()} />
            {preview ? (
              <div className="relative">
                <img
                  ref={imgRef}
                  src={preview}
                  alt="Selected"
                  className="max-h-64 mx-auto rounded-xl object-contain"
                />
                <button
                  onClick={e => { e.stopPropagation(); handleClear() }}
                  className="absolute top-2 right-2 bg-surface-800/80 hover:bg-red-500/80 rounded-full p-1 transition-colors"
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <div className="py-6">
                <div className="w-14 h-14 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <Upload size={22} className="text-accent" />
                </div>
                <p className="font-display font-semibold mb-1">
                  {isDragActive ? 'Drop it here!' : 'Drop an image here'}
                </p>
                <p className="text-white/40 text-sm">or click to browse · max 10MB</p>
              </div>
            )}
          </div>

          <button
            onClick={handleDetect}
            disabled={!selectedFile || loading}
            className="w-full btn-primary flex items-center justify-center gap-2"
          >
            {loading ? (
              <><Loader2 size={16} className="animate-spin" /> Analyzing…</>
            ) : (
              <><ImageIcon size={16} /> Detect Objects</>
            )}
          </button>

          {result && (
            <div className="grid grid-cols-2 gap-2">
              <button onClick={handleDownload} className="btn-ghost flex items-center justify-center gap-2 text-sm">
                <Download size={14} /> Annotated Image
              </button>
              <button onClick={exportJSON} className="btn-ghost flex items-center justify-center gap-2 text-sm">
                <Download size={14} /> Export JSON
              </button>
            </div>
          )}
        </div>

        {/* Result panel */}
        <div className="space-y-4">
          {loading && (
            <div className="card p-8 text-center animate-pulse-slow">
              <Loader2 size={32} className="animate-spin text-accent mx-auto mb-3" />
              <p className="font-display font-semibold">Running YOLOv8 inference…</p>
              <p className="text-white/40 text-sm mt-1">This may take a moment</p>
            </div>
          )}

          {result && !loading && (
            <>
              {/* Annotated image with boxes */}
              {result.image_url ? (
                <div className="card overflow-hidden">
                  <img src={result.image_url} alt="Annotated" className="w-full object-contain max-h-72" />
                </div>
              ) : preview && (
                <BoundingBoxCanvas imageSrc={preview} objects={result.objects} confidenceThreshold={confidence} />
              )}

              {/* Stats bar */}
              <div className="card p-4 flex items-center gap-4">
                <CheckCircle2 size={18} className="text-neon-green shrink-0" />
                <div className="flex-1">
                  <p className="text-sm font-semibold">{result.total_objects} objects detected</p>
                  <p className="text-xs text-white/40">Inference: {result.inference_time_ms}ms</p>
                </div>
              </div>

              {/* Detection list */}
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {result.objects.length === 0 ? (
                  <div className="card p-6 text-center">
                    <AlertCircle size={24} className="text-neon-amber mx-auto mb-2" />
                    <p className="text-sm text-white/60">No objects above {Math.round(confidence * 100)}% confidence</p>
                  </div>
                ) : (
                  result.objects.map((obj, i) => (
                    <DetectionResultCard key={i} obj={obj} index={i} />
                  ))
                )}
              </div>
            </>
          )}

          {!result && !loading && (
            <div className="card p-10 text-center text-white/30">
              <ImageIcon size={32} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">Detection results will appear here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
