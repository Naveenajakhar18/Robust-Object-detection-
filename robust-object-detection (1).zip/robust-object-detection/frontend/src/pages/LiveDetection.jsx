import { useState, useRef, useCallback } from 'react'
import Webcam from 'react-webcam'
import { getVideoStreamUrl } from '../services/api'
import { Video, VideoOff, Camera, Loader2, Wifi, WifiOff } from 'lucide-react'
import toast from 'react-hot-toast'

const VIDEO_CONSTRAINTS = {
  width: 1280, height: 720, facingMode: 'user'
}

export default function LiveDetection() {
  const [mode, setMode] = useState('idle') // idle | webcam | stream
  const [streamError, setStreamError] = useState(false)
  const webcamRef = useRef(null)
  const streamUrl = getVideoStreamUrl()

  const startWebcam = () => {
    setMode('webcam')
    toast.success('Webcam activated — backend stream requires running backend')
  }

  const startStream = () => {
    setMode('stream')
    setStreamError(false)
  }

  const stop = () => {
    setMode('idle')
    setStreamError(false)
  }

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold">Live Detection</h1>
        <p className="text-white/40 text-sm mt-1">Real-time object detection via webcam or MJPEG stream</p>
      </div>

      {/* Info banner */}
      <div className="card p-4 flex items-start gap-3 border-neon-cyan/20 bg-neon-cyan/5">
        <Wifi size={16} className="text-neon-cyan shrink-0 mt-0.5" />
        <div className="text-sm">
          <p className="font-semibold text-neon-cyan">Backend Stream Mode</p>
          <p className="text-white/50 text-xs mt-0.5">
            The MJPEG stream requires the FastAPI backend running locally with a webcam attached.
            Use "Frontend Webcam" mode to capture frames and send to the API individually.
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={startWebcam}
          disabled={mode !== 'idle'}
          className={`btn-primary flex items-center gap-2 text-sm ${mode === 'webcam' ? 'opacity-50' : ''}`}
        >
          <Camera size={15} /> Frontend Webcam
        </button>
        <button
          onClick={startStream}
          disabled={mode !== 'idle'}
          className="btn-ghost flex items-center gap-2 text-sm"
        >
          <Video size={15} /> Backend Stream (MJPEG)
        </button>
        {mode !== 'idle' && (
          <button onClick={stop} className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 px-4 py-2.5 rounded-xl border border-red-500/30 hover:bg-red-500/10 transition-all">
            <VideoOff size={15} /> Stop
          </button>
        )}
      </div>

      {/* Video area */}
      <div className="card overflow-hidden aspect-video flex items-center justify-center relative bg-surface-900">
        {mode === 'idle' && (
          <div className="text-center">
            <Video size={40} className="text-white/10 mx-auto mb-3" />
            <p className="text-white/30 text-sm">Select a detection mode above</p>
          </div>
        )}

        {mode === 'webcam' && (
          <Webcam
            ref={webcamRef}
            audio={false}
            videoConstraints={VIDEO_CONSTRAINTS}
            className="w-full h-full object-cover"
            onUserMediaError={() => toast.error('Webcam access denied or unavailable')}
          />
        )}

        {mode === 'stream' && (
          <>
            {streamError ? (
              <div className="text-center">
                <WifiOff size={40} className="text-red-400 mx-auto mb-3" />
                <p className="text-red-400 font-semibold text-sm">Backend stream unavailable</p>
                <p className="text-white/40 text-xs mt-1">Make sure the FastAPI backend is running on port 8000</p>
              </div>
            ) : (
              <img
                src={streamUrl}
                alt="Live detection stream"
                className="w-full h-full object-contain"
                onError={() => setStreamError(true)}
              />
            )}
          </>
        )}

        {/* Live indicator */}
        {mode !== 'idle' && !streamError && (
          <div className="absolute top-3 left-3 flex items-center gap-2 bg-black/60 backdrop-blur rounded-full px-3 py-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs font-mono text-white/80">LIVE</span>
          </div>
        )}
      </div>

      {/* Tips */}
      <div className="grid sm:grid-cols-2 gap-4">
        {[
          { title: 'Frontend Webcam', desc: 'Accesses your browser webcam. Frames are displayed locally; you can extend to send frames to the API via WebSocket.' },
          { title: 'Backend MJPEG Stream', desc: 'Backend opens /detect-video and streams annotated frames. Requires webcam attached to the server machine.' },
        ].map(({ title, desc }) => (
          <div key={title} className="card p-4">
            <p className="font-display font-semibold text-sm mb-1">{title}</p>
            <p className="text-white/40 text-xs">{desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
