import { useEffect, useRef } from 'react'

const COLORS = [
  '#6c47ff','#00d4ff','#00ff94','#ffb347','#ff6b6b',
  '#c084fc','#34d399','#fbbf24','#f87171','#60a5fa'
]

export default function BoundingBoxCanvas({ imageSrc, objects = [], confidenceThreshold = 0.25 }) {
  const canvasRef = useRef(null)
  const imgRef = useRef(null)

  useEffect(() => {
    if (!imageSrc || !canvasRef.current) return
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const img = new Image()
    img.src = imageSrc

    img.onload = () => {
      canvas.width = img.naturalWidth
      canvas.height = img.naturalHeight
      ctx.drawImage(img, 0, 0)

      const filtered = objects.filter(o => o.confidence >= confidenceThreshold)
      filtered.forEach((obj, i) => {
        const color = COLORS[i % COLORS.length]
        const { x, y, width, height } = obj.bbox

        // Box
        ctx.strokeStyle = color
        ctx.lineWidth = Math.max(2, canvas.width / 400)
        ctx.strokeRect(x, y, width, height)

        // Label bg
        const label = `${obj.label} ${Math.round(obj.confidence * 100)}%`
        const fontSize = Math.max(12, canvas.width / 60)
        ctx.font = `bold ${fontSize}px DM Sans, sans-serif`
        const textW = ctx.measureText(label).width
        const padX = 6, padY = 4
        const labelH = fontSize + padY * 2
        const labelY = y > labelH + 4 ? y - labelH - 2 : y + 2

        ctx.fillStyle = color
        ctx.beginPath()
        ctx.roundRect(x - 1, labelY, textW + padX * 2, labelH, 4)
        ctx.fill()

        ctx.fillStyle = '#ffffff'
        ctx.fillText(label, x + padX - 1, labelY + labelH - padY - 2)
      })
    }
  }, [imageSrc, objects, confidenceThreshold])

  return (
    <div className="card overflow-hidden">
      <canvas ref={canvasRef} className="w-full object-contain max-h-72" />
    </div>
  )
}
