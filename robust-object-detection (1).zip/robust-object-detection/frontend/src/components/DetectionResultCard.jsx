const COLORS = [
  'border-l-[#6c47ff]', 'border-l-[#00d4ff]', 'border-l-[#00ff94]',
  'border-l-[#ffb347]', 'border-l-[#ff6b6b]', 'border-l-[#c084fc]'
]

export default function DetectionResultCard({ obj, index }) {
  const conf = Math.round(obj.confidence * 100)
  const colorClass = COLORS[index % COLORS.length]

  return (
    <div className={`card border-l-4 ${colorClass} p-3 flex items-center gap-3 animate-slide-up`}
      style={{ animationDelay: `${index * 40}ms` }}>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1.5">
          <p className="font-display font-semibold text-sm capitalize">{obj.label}</p>
          <span className="font-mono text-xs text-white/60">{conf}%</span>
        </div>
        <div className="h-1.5 bg-surface-600 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${conf}%`,
              background: `linear-gradient(90deg, #6c47ff, #00d4ff)`
            }}
          />
        </div>
        <p className="text-xs text-white/30 mt-1 font-mono">
          x:{obj.bbox.x} y:{obj.bbox.y} {obj.bbox.width}×{obj.bbox.height}
        </p>
      </div>
    </div>
  )
}
