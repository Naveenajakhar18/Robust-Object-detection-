from fastapi import APIRouter, Query, Depends
from services.db_service import DBService
from utils.auth_utils import get_current_user_optional

router = APIRouter()
db = DBService()


@router.get("/history")
async def get_detection_history(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user_optional)
):
    """Get paginated detection history"""
    user_id = current_user.get("user_id") if current_user else None
    results = db.get_detections(page=page, limit=limit, user_id=user_id)
    return results


@router.get("/analytics")
async def get_analytics():
    """Get detection analytics for dashboard charts"""
    return db.get_analytics()


@router.delete("/history/{detection_id}")
async def delete_detection(
    detection_id: str,
    current_user: dict = Depends(get_current_user_optional)
):
    """Delete a detection record"""
    deleted = db.delete_detection(detection_id)
    if not deleted:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Detection not found")
    return {"message": "Deleted successfully"}
