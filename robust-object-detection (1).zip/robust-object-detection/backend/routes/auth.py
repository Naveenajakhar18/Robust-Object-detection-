from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr
from services.db_service import DBService
from utils.auth_utils import (
    hash_password, verify_password, create_access_token, get_current_user
)

router = APIRouter()
db = DBService()


class UserRegister(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: str = "user"  # "user" or "admin"


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str
    user: dict


@router.post("/register", response_model=Token)
async def register(user_data: UserRegister):
    # Check if user exists
    existing = db.get_user_by_email(user_data.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed = hash_password(user_data.password)
    user_id = db.create_user({
        "email": user_data.email,
        "password": hashed,
        "name": user_data.name,
        "role": user_data.role
    })

    token = create_access_token({"user_id": str(user_id), "email": user_data.email, "role": user_data.role})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": str(user_id), "email": user_data.email, "name": user_data.name, "role": user_data.role}
    }


@router.post("/login", response_model=Token)
async def login(credentials: UserLogin):
    user = db.get_user_by_email(credentials.email)
    if not user or not verify_password(credentials.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token({
        "user_id": str(user["_id"]),
        "email": user["email"],
        "role": user.get("role", "user")
    })
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": str(user["_id"]),
            "email": user["email"],
            "name": user.get("name", ""),
            "role": user.get("role", "user")
        }
    }


@router.get("/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    return current_user
