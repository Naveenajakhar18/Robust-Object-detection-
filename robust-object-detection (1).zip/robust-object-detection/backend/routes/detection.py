from fastapi import APIRouter, File, UploadFile, HTTPException, Depends
from fastapi.responses import StreamingResponse
import io, time

from services.yolo_service import YOLOService
from services.db_service import DBService
from services.storage_service import save_annotated_image
from models.detection_model import DetectionResult
from utils.auth_utils import get_current_user_optional

router = APIRouter()
yolo = YOLOService()
db = DBService()


@router.post("/detect-image", response_model=DetectionResult)
async def detect_image(
    file: UploadFile = File(...),
    confidence_threshold: float = 0.25,
    current_user: dict = Depends(get_current_user_optional)
):
    """
    Upload an image for object detection.
    Returns bounding boxes, labels, and confidence scores.
    """
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")

    contents = await file.read()
    if len(contents) > 10 * 1024 * 1024:  # 10MB limit
        raise HTTPException(status_code=400, detail="File too large (max 10MB)")

    # Run detection
    start_time = time.time()
    result = yolo.detect_image(contents, confidence_threshold)
    inference_time = time.time() - start_time

    # Save annotated image
    image_url = save_annotated_image(result["annotated_image"], file.filename)

    # Save to DB
    detection_record = {
        "filename": file.filename,
        "image_url": image_url,
        "objects_detected": result["objects"],
        "inference_time_ms": round(inference_time * 1000, 2),
        "confidence_threshold": confidence_threshold,
        "user_id": current_user.get("user_id") if current_user else None
    }
    detection_id = db.save_detection(detection_record)

    return {
        "id": str(detection_id),
        "objects": result["objects"],
        "image_url": image_url,
        "inference_time_ms": detection_record["inference_time_ms"],
        "total_objects": len(result["objects"]),
        "filename": file.filename
    }


@router.get("/detect-video")
async def detect_video_stream():
    """
    Stream webcam detection as MJPEG.
    Returns real-time annotated frames.
    """
    def generate_frames():
        import cv2
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            # Return a placeholder frame if no webcam
            import numpy as np
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
            cv2.putText(frame, "No webcam available", (150, 240),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            _, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' +
                   buffer.tobytes() + b'\r\n')
            return

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                annotated = yolo.detect_frame(frame)
                _, buffer = cv2.imencode('.jpg', annotated)
                yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' +
                       buffer.tobytes() + b'\r\n')
        finally:
            cap.release()

    return StreamingResponse(
        generate_frames(),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )
