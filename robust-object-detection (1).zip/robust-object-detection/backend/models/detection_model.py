from pydantic import BaseModel
from typing import List, Optional


class BoundingBox(BaseModel):
    x: float
    y: float
    width: float
    height: float


class DetectedObject(BaseModel):
    label: str
    confidence: float
    bbox: BoundingBox
    class_id: int


class DetectionResult(BaseModel):
    id: Optional[str] = None
    objects: List[DetectedObject]
    image_url: Optional[str] = None
    inference_time_ms: Optional[float] = None
    total_objects: int
    filename: Optional[str] = None
