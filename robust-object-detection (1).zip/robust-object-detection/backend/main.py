from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from routes import detection, auth, history

app = FastAPI(
    title="Robust Object Detection API",
    description="Production-grade object detection using YOLOv8 + COCO dataset",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production: restrict to frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files for annotated images
os.makedirs("static/annotated", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Routers
app.include_router(detection.router, prefix="/api", tags=["Detection"])
app.include_router(auth.router, prefix="/api/auth", tags=["Auth"])
app.include_router(history.router, prefix="/api", tags=["History"])


@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "message": "Robust Object Detection API is running",
        "version": "1.0.0"
    }


@app.get("/")
async def root():
    return {"message": "Welcome to the Robust Object Detection API. Visit /docs for API documentation."}
