import cv2
import numpy as np
from ultralytics import YOLO
import os
import torch

# ── PyTorch 2.6 compatibility fix ──────────────────────────────────────────
# PyTorch 2.6 changed torch.load default to weights_only=True which breaks
# older Ultralytics checkpoints. This allowlists the required globals.
try:
    from ultralytics.nn.tasks import DetectionModel
    from torch.serialization import add_safe_globals
    add_safe_globals([DetectionModel])
except Exception:
    pass


class YOLOService:
    def __init__(self, model_name: str = "yolov8n.pt"):
        """Initialize YOLOv8 with pre-trained COCO weights"""
        self.model = YOLO(model_name)
        self.class_names = self.model.names
        self.colors = self._generate_colors()

    def _generate_colors(self):
        """Generate distinct colors for each class"""
        np.random.seed(42)
        return {i: tuple(np.random.randint(50, 255, 3).tolist())
                for i in range(len(self.class_names))}

    def detect_image(self, image_bytes: bytes, confidence_threshold: float = 0.25):
        """Run YOLOv8 inference on image bytes"""
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if img is None:
            raise ValueError("Could not decode image")

        results = self.model(img, conf=confidence_threshold, verbose=False)[0]
        objects = self._parse_results(results)
        annotated = self._draw_boxes(img.copy(), results, confidence_threshold)

        _, buffer = cv2.imencode('.jpg', annotated, [cv2.IMWRITE_JPEG_QUALITY, 92])
        return {
            "objects": objects,
            "annotated_image": buffer.tobytes()
        }

    def detect_frame(self, frame: np.ndarray, confidence_threshold: float = 0.25):
        """Run YOLOv8 inference on a single video frame"""
        results = self.model(frame, conf=confidence_threshold, verbose=False)[0]
        return self._draw_boxes(frame, results, confidence_threshold)

    def _parse_results(self, results):
        """Extract detection data from YOLO results"""
        objects = []
        if results.boxes is None:
            return objects

        for box in results.boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            conf = float(box.conf[0])
            cls_id = int(box.cls[0])
            label = self.class_names.get(cls_id, f"class_{cls_id}")

            objects.append({
                "label": label,
                "confidence": round(conf, 4),
                "bbox": {
                    "x": round(x1),
                    "y": round(y1),
                    "width": round(x2 - x1),
                    "height": round(y2 - y1)
                },
                "class_id": cls_id
            })

        objects.sort(key=lambda x: x["confidence"], reverse=True)
        return objects

    def _draw_boxes(self, img, results, confidence_threshold: float):
        """Draw bounding boxes and labels on image"""
        if results.boxes is None:
            return img

        for box in results.boxes:
            conf = float(box.conf[0])
            if conf < confidence_threshold:
                continue

            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            cls_id = int(box.cls[0])
            label = self.class_names.get(cls_id, f"class_{cls_id}")
            color = self.colors.get(cls_id, (0, 255, 0))

            cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)

            text = f"{label} {conf:.0%}"
            (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_DUPLEX, 0.6, 1)
            label_y = max(y1, th + 10)
            cv2.rectangle(img, (x1, label_y - th - 8), (x1 + tw + 6, label_y + 2), color, -1)
            cv2.putText(img, text, (x1 + 3, label_y - 3),
                        cv2.FONT_HERSHEY_DUPLEX, 0.6, (255, 255, 255), 1, cv2.LINE_AA)

        return img
