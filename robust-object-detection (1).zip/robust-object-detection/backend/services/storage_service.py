import os
import uuid
from datetime import datetime

STATIC_DIR = "static/annotated"
os.makedirs(STATIC_DIR, exist_ok=True)

BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")


def save_annotated_image(image_bytes: bytes, original_filename: str) -> str:
    """Save annotated image to disk and return its public URL"""
    ext = os.path.splitext(original_filename)[-1] or ".jpg"
    unique_name = f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}{ext}"
    path = os.path.join(STATIC_DIR, unique_name)

    with open(path, "wb") as f:
        f.write(image_bytes)

    return f"{BASE_URL}/static/annotated/{unique_name}"
