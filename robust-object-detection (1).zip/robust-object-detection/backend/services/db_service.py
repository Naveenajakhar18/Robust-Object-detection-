from pymongo import MongoClient, DESCENDING
from bson import ObjectId
from datetime import datetime, timezone
import os
from collections import defaultdict


class DBService:
    def __init__(self):
        mongo_uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
        self.client = MongoClient(mongo_uri)
        self.db = self.client["object_detection"]
        self.detections = self.db["detections"]
        self.images = self.db["images"]
        self.users = self.db["users"]
        self._create_indexes()

    def _create_indexes(self):
        self.detections.create_index([("timestamp", DESCENDING)])
        self.detections.create_index([("user_id", 1)])
        self.users.create_index([("email", 1)], unique=True)

    # ── Detection CRUD ─────────────────────────────────────────────────────────

    def save_detection(self, data: dict) -> str:
        record = {
            **data,
            "timestamp": datetime.now(timezone.utc)
        }
        result = self.detections.insert_one(record)
        return result.inserted_id

    def get_detections(self, page: int = 1, limit: int = 20, user_id: str = None):
        query = {}
        if user_id:
            query["user_id"] = user_id

        total = self.detections.count_documents(query)
        skip = (page - 1) * limit
        cursor = (self.detections.find(query)
                  .sort("timestamp", DESCENDING)
                  .skip(skip).limit(limit))

        items = []
        for doc in cursor:
            doc["id"] = str(doc.pop("_id"))
            if "timestamp" in doc and hasattr(doc["timestamp"], "isoformat"):
                doc["timestamp"] = doc["timestamp"].isoformat()
            items.append(doc)

        return {
            "items": items,
            "total": total,
            "page": page,
            "pages": (total + limit - 1) // limit
        }

    def delete_detection(self, detection_id: str) -> bool:
        try:
            result = self.detections.delete_one({"_id": ObjectId(detection_id)})
            return result.deleted_count > 0
        except Exception:
            return False

    def get_analytics(self):
        """Return aggregated analytics for dashboard"""
        pipeline = [
            {
                "$group": {
                    "_id": {
                        "year": {"$year": "$timestamp"},
                        "month": {"$month": "$timestamp"},
                        "day": {"$dayOfMonth": "$timestamp"}
                    },
                    "count": {"$sum": 1},
                    "total_objects": {"$sum": {"$size": "$objects_detected"}}
                }
            },
            {"$sort": {"_id.year": 1, "_id.month": 1, "_id.day": 1}},
            {"$limit": 30}
        ]

        daily_data = []
        try:
            for doc in self.detections.aggregate(pipeline):
                d = doc["_id"]
                daily_data.append({
                    "date": f"{d['year']}-{d['month']:02d}-{d['day']:02d}",
                    "detections": doc["count"],
                    "objects": doc["total_objects"]
                })
        except Exception:
            pass

        # Label frequency
        label_counts = defaultdict(int)
        try:
            for doc in self.detections.find({}, {"objects_detected": 1}):
                for obj in doc.get("objects_detected", []):
                    label_counts[obj.get("label", "unknown")] += 1
        except Exception:
            pass

        top_labels = sorted(label_counts.items(), key=lambda x: x[1], reverse=True)[:10]

        total_detections = self.detections.count_documents({})
        total_objects = sum(label_counts.values())

        return {
            "total_detections": total_detections,
            "total_objects": total_objects,
            "daily_data": daily_data,
            "top_labels": [{"label": k, "count": v} for k, v in top_labels],
            "unique_classes": len(label_counts)
        }

    # ── User CRUD ──────────────────────────────────────────────────────────────

    def create_user(self, data: dict) -> str:
        data["created_at"] = datetime.now(timezone.utc)
        result = self.users.insert_one(data)
        return result.inserted_id

    def get_user_by_email(self, email: str):
        return self.users.find_one({"email": email})

    def get_user_by_id(self, user_id: str):
        try:
            return self.users.find_one({"_id": ObjectId(user_id)})
        except Exception:
            return None
